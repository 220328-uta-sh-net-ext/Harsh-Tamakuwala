-- DROP TABLE Users;
CREATE TABLE Users (
    userID int NOT NULL IDENTITY(1,1) PRIMARY KEY,
    FirstName nvarchar(50),
    LastName nvarchar(50) NOT NULL,  
    EmailId nvarchar(50) NOT NULL UNIQUE,
    UserPassword nvarchar(50) NOT NULL,
    ContactNo NUMERIC,

);


INSERT INTO Users(FirstName,LastName,EmailId,UserPassword,ContactNo)VALUES
('harsh','tamakuwala','harsh@gmail.com','harsh123@',7878234598),
('neel','patel','neel123@gmail.com','neel3434$',3234567854)


SELECT * from Users;

-- DROP TABLE Restaurants;
CREATE TABLE Restaurants (
    RestaurantId int NOT NULL IDENTITY(1,1) PRIMARY KEY,
    RestaurantName varchar(255) NOT NULL,
    RestaurantAddress1 varchar(255),
    RestaurantCity VARCHAR(20),
    RestaurantState VARCHAR(20),
    RestaurantZipCode varchar(255) NOT NULL,
    Costtype varchar(4) NOT NULL,
    Website varchar(500),
    Phoneno NUMERIC UNIQUE

);

INSERT INTO Restaurants(RestaurantName,RestaurantAddress1,RestaurantCity,RestaurantState,RestaurantZipCode,Costtype,Website,Phoneno)VALUES
('Salt n Straw','246 NW 25th St','Miami', 'FL','33127','$$','https://saltandstraw.com',7866330157),
('Pita House','2016 NY-112', 'Medford', 'NY','11763','$','https://www.longislandpitahouse.com/?utm_source=google&utm_medium=gmb&utm_campaign=gmb',6312892262)


SELECT * from Restaurants;


-- DROP TABLE Reviews;
CREATE TABLE Reviews (
    ReviewID int NOT NULL IDENTITY(1,1) PRIMARY KEY,
    RestaurantId int FOREIGN KEY REFERENCES Restaurants(RestaurantId),
    RatedBy int FOREIGN KEY REFERENCES Users(userID),
    Ratings FLOAT not NULL,
    Note nvarchar(200) NOT NULL,  
    Reviewtime DATETIME2 DEFAULT SYSDATETIME(), 
    UNIQUE(RestaurantId,RatedBy)
);

INSERT INTO Reviews(RestaurantId,Ratings,Note,RatedBy)VALUES
(2,5,'Nice restaurant, food is sawesome',1),
(1,3,'Service is awesome!!',2)

select * from Reviews;




